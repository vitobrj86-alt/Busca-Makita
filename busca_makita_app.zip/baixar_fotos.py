"""Baixa a foto principal de cada item "só site" para a pasta fotos/.
Uso: coloque este arquivo na mesma pasta do index.html e execute (precisa de internet e Python 3).
Pode rodar de novo: pula o que já foi baixado."""
import json, os, re, sys, time, urllib.request

AQUI = os.path.dirname(os.path.abspath(__file__))
PASTA = os.path.join(AQUI, 'fotos')
os.makedirs(PASTA, exist_ok=True)
UA = {'User-Agent': 'Mozilla/5.0'}

def pega(url, binario=False):
    for _ in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
                d = r.read()
                return d if binario else d.decode('utf-8', 'ignore')
        except Exception:
            time.sleep(1.5)
    return None

itens = json.load(open(os.path.join(AQUI, 'lista_fotos.json'), encoding='utf-8'))
ok = falha = 0
for i, (codigo, link) in enumerate(itens, 1):
    nome = re.sub(r'[^A-Za-z0-9]', '', codigo).upper() + '.jpg'
    destino = os.path.join(PASTA, nome)
    if os.path.exists(destino):
        ok += 1
        continue
    html = pega(link) if link else None
    fotos = re.findall(r'https?://storagesitemakita\.blob\.core\.windows\.net/arquivos/[^"\'\s<>)]+\.(?:jpg|jpeg|png)', html or '', re.I)
    foto = next((f for f in fotos if codigo.upper() in f.upper()), fotos[0] if fotos else None)
    dados = pega(foto, True) if foto else None
    if dados and len(dados) > 2000:
        open(destino, 'wb').write(dados)
        ok += 1
    else:
        falha += 1
        print('sem foto:', codigo, link)
    print(f'{i}/{len(itens)}', end='\r')
print(f'\nBaixadas: {ok}  Sem foto: {falha}')
